using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace FinancialPlanningApp.Pages
{
    public class IndexModel : PageModel
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public IndexModel(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        [BindProperty]
        public IFormFile BankStatement { get; set; }
        [BindProperty]
        public IFormFile PropertyValuation { get; set; }
        [BindProperty]
        public IFormFile WealthPortfolio { get; set; }
        [BindProperty]
        public IFormFile HealthScreening { get; set; }

        public string AnalysisResult { get; private set; }

        public void OnGet()
        {
            AnalysisResult = string.Empty;
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (BankStatement == null || PropertyValuation == null || WealthPortfolio == null || HealthScreening == null)
            {
                AnalysisResult = "Please upload all the required documents.";
                return Page();
            }

            // Process and analyze the uploaded documents
            var bankStatementText = await ReadFileContentAsync(BankStatement);
            var propertyValuationText = await ReadFileContentAsync(PropertyValuation);
            var wealthPortfolioText = await ReadFileContentAsync(WealthPortfolio);
            var healthScreeningText = await ReadFileContentAsync(HealthScreening);

            var combinedText = $"Bank Statement:\n{bankStatementText}\n\n" +
                               $"Property Valuation Report:\n{propertyValuationText}\n\n" +
                               $"Wealth Portfolio Report:\n{wealthPortfolioText}\n\n" +
                               $"Health Screening Report:\n{healthScreeningText}";

            AnalysisResult = await GetGptAnalysis(combinedText);
            
            // Redirect to Chat page with the analysis result
            return RedirectToPage("Chat", new { financialPlan = AnalysisResult });
        }

        private async Task<string> ReadFileContentAsync(IFormFile file)
        {
            using var reader = new StreamReader(file.OpenReadStream());
            return await reader.ReadToEndAsync();
        }

        private async Task<string> GetGptAnalysis(string combinedText)
        {
            using var httpClient = _httpClientFactory.CreateClient();
            var requestContent = new StringContent($"{{\"prompt\": \"Based on the following documents, provide detailed retirement financial planning: {combinedText}\", \"max_tokens\": 1000}}", Encoding.UTF8, "application/json");
            requestContent.Headers.Authorization = new AuthenticationHeaderValue("Bearer", "YOUR_OPENAI_API_KEY");

            var response = await httpClient.PostAsync("https://api.openai.com/v1/engines/davinci-codex/completions", requestContent);
            response.EnsureSuccessStatusCode();

            var gptResponse = await response.Content.ReadAsStringAsync();
            return gptResponse;
        }
    }
}
