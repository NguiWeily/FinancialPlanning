using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace FinancialPlanningApp.Pages
{
    public class IndexModel : PageModel
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(IHttpClientFactory httpClientFactory, ILogger<IndexModel> logger)
        {
            _httpClientFactory = httpClientFactory;
            _logger = logger;
            AnalysisResult = string.Empty;
            TalkToUs = false;
        }

        [BindProperty]
        public string? Name { get; set; }
        [BindProperty]
        public int? Age { get; set; }
        [BindProperty]
        public decimal? IncomePerMonth { get; set; }
        [BindProperty]
        public decimal? NetWorth { get; set; }
        [BindProperty]
        public int? RetirementAge { get; set; }
        [BindProperty]
        public decimal? MonthlyRetirementExpense { get; set; }
        [BindProperty]
        public IFormFile? BankStatement { get; set; }
        [BindProperty]
        public IFormFile? PropertyValuation { get; set; }
        [BindProperty]
        public IFormFile? WealthPortfolio { get; set; }
        [BindProperty]
        public IFormFile? HealthScreening { get; set; }

        public string AnalysisResult { get; private set; }
        public bool TalkToUs { get; private set; }

        public void OnGet()
        {
            AnalysisResult = string.Empty;
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                _logger.LogError("Model state is invalid.");
                return Page();
            }

            var userDetails = new StringBuilder();
            userDetails.AppendLine($"Name: {Name}");
            userDetails.AppendLine($"Age: {Age}");
            userDetails.AppendLine($"Income Per Month: {IncomePerMonth}");
            userDetails.AppendLine($"Net Worth: {NetWorth}");
            userDetails.AppendLine($"Retirement Age Plan: {RetirementAge}");
            userDetails.AppendLine($"Monthly Retirement Expense Plan: {MonthlyRetirementExpense}");

            if (BankStatement == null || PropertyValuation == null || WealthPortfolio == null || HealthScreening == null)
            {
                AnalysisResult = "Please upload all the required documents.";
                return Page();
            }

            // Process and analyze the uploaded documents
            var bankStatementText = await ReadFileContentAsync(BankStatement);
            var propertyValuationText = await ReadFileContentAsync(PropertyValuation);
            var wealthPortfolioText = await ReadFileContentAsync(WealthPortfolio);
            var healthScreeningText = await ReadFileContentAsync(HealthScreening);

            var combinedText = $"{userDetails}\n\n" +
                               $"Bank Statement:\n{bankStatementText}\n\n" +
                               $"Property Valuation Report:\n{propertyValuationText}\n\n" +
                               $"Wealth Portfolio Report:\n{wealthPortfolioText}\n\n" +
                               $"Health Screening Report:\n{healthScreeningText}";

            try
            {
                AnalysisResult = await GetGptAnalysis(combinedText);
                TalkToUs = true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while getting GPT analysis.");
                AnalysisResult = "An error occurred while processing your request. Please try again later.";
            }

            return Page();
        }

        private async Task<string> ReadFileContentAsync(IFormFile file)
        {
            using var reader = new StreamReader(file.OpenReadStream());
            return await reader.ReadToEndAsync();
        }

private async Task<string> GetGptAnalysis(string combinedText)
{
    using var httpClient = _httpClientFactory.CreateClient();

    var requestBody = new
    {
        model = "gpt-3.5-turbo",
        messages = new[]
        {
            new { role = "system", content = "You are a financial advisor." },
            new { role = "user", content = $"Based on the following documents and details, provide detailed retirement financial planning with multiple assumptions and scenarios if any information is missing: {combinedText}" }
        },
        max_tokens = 1000
    };

    var requestJson = JsonSerializer.Serialize(requestBody);
    var requestContent = new StringContent(requestJson, Encoding.UTF8, "application/json");

    var request = new HttpRequestMessage
    {
        Method = HttpMethod.Post,
        RequestUri = new Uri("https://api.openai.com/v1/chat/completions"),
        Content = requestContent
    };

    // Replace "YOUR_OPENAI_API_KEY" with your actual API key
    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", "YOUR_OPENAI_API_KEY");

    var response = await httpClient.SendAsync(request);

    if (!response.IsSuccessStatusCode)
    {
        var errorResponse = await response.Content.ReadAsStringAsync();
        _logger.LogError("Request failed with status code {StatusCode}: {ErrorResponse}", response.StatusCode, errorResponse);
        throw new Exception($"Request failed with status code {response.StatusCode}: {errorResponse}");
    }

    var gptResponse = await response.Content.ReadAsStringAsync();
    var gptResponseObject = JsonDocument.Parse(gptResponse);

    // Ensure we return a non-null string
    return gptResponseObject.RootElement.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString() ?? "No response from GPT-3.5 Turbo.";
        }
    }
}
