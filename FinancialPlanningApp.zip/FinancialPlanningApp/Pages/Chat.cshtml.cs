using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace FinancialPlanningApp.Pages
{
    public class ChatModel : PageModel
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public ChatModel(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
            UserInput = string.Empty;
            GptResponse = string.Empty;
            FinancialPlan = string.Empty;
        }

        [BindProperty]
        public string UserInput { get; set; }
        public string GptResponse { get; private set; }
        public string FinancialPlan { get; private set; }

        public void OnGet(string financialPlan)
        {
            FinancialPlan = financialPlan;
            GptResponse = string.Empty;
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (string.IsNullOrEmpty(UserInput))
            {
                GptResponse = "Please enter a message.";
                return Page();
            }

            GptResponse = await GetGptResponse(UserInput);
            return Page();
        }

        private async Task<string> GetGptResponse(string userInput)
        {
            using var httpClient = _httpClientFactory.CreateClient();
            var requestContent = new StringContent(
                $"{{\"prompt\": \"{userInput}\", \"max_tokens\": 150}}", 
                Encoding.UTF8, 
                "application/json"
            );

            var request = new HttpRequestMessage
            {
                Method = HttpMethod.Post,
                RequestUri = new Uri("https://api.openai.com/v1/engines/davinci-codex/completions"),
                Content = requestContent
            };

            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", "YOUR_OPENAI_API_KEY");

            var response = await httpClient.SendAsync(request);
            response.EnsureSuccessStatusCode();

            var gptResponse = await response.Content.ReadAsStringAsync();
            return gptResponse;
        }
    }
}
